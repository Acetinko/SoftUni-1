let functions = require('./loadData');

result.sort = functions.sort;
result.filter = functions.filter;